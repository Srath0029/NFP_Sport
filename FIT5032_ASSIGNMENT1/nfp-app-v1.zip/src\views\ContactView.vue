<template>
  <div class="container mt-5">
    <h2>Contact Us</h2>
    <p class="mb-1">Email: <strong>info@nfp-example.org</strong></p>
    <p class="mb-0">Location: Melbourne, VIC</p>
  </div>
</template>

<script setup>
</script>
