<template>
  <div class="container mt-5">
    <h2>About</h2>
    <p>
      This not-for-profit web application promotes health and wellbeing through community sport.
      Members can register, connect, and discover opportunities to get active.
    </p>
  </div>
</template>

<script setup>
</script>
