<!-- src/App.vue -->
<template>
  <div id="app">
    <NavBar />
    <RouterView />
  </div>
</template>

<script setup>
import NavBar from "./components/NavBar.vue";
</script>
